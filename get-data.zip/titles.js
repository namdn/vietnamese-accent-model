var Crawler = require("crawler");
var fs = require('fs');
require('gf-js');



var c = new Crawler({
    // encoding:null,
    maxConnections : 10,
    // jQuery:false,// set false to suppress warning message.
    callback:function(err, res, done){
        if(err){
            console.error(err.stack);
        }else{
            console.log(res.options.uri);
            let $ = res.$;
            let links = $('h3>a')
                .toArray()
                .map(a=>'http://cafef.vn'  + $(a).attr('href') + '\n')
                .join('')
            
            fs.appendFileSync(res.options.filename, links);
        }
        
        done();
    }
});



let pages = Array.range(1,3000).map(i=>({
    uri:`http://cafef.vn/timeline/34/trang-${i}.chn`,
    filename:'cafef.vn/nganhang.txt'
}));


// let pages = Array.range(1,3000).map(i=>({
//     uri:`http://cafef.vn/timeline/34/trang-${i}.chn`,
//     filename:'cafef.vn/nganhang.txt'
// }))


c.queue(pages)

