var Crawler = require("crawler");
var fs = require('fs');
require('gf-js');

let n = 0;

var c = new Crawler({
    // encoding:null,
    maxConnections: 10,
    // jQuery:false,// set false to suppress warning message.
    callback: function (err, res, done) {
        if (err) {
            console.error(err.stack);
        } else {
            let uri = res.options.uri;
            let [filename] = uri.split('/').slice(-1);
            filename = 'cafef.vn/nganhang/' + filename;

            let $ = res.$;
            let text = $('p')
                .toArray()
                .map(p => $(p).text())
                .join('\r\n');

            text = text
                .split('\r\n')
                .filter(p => p.length > 20)
                .join('\r\n');

            fs.writeFileSync(filename, text);
            
            n = n + 1;

            if (n % 10 == 0)
                process.stdout.write(`number of links: ${n}\r`);
            // console.log(n,'\r');
            // console.log(filename);
        }

        done();
    }
});



let links = fs
    .readFileSync('cafef.vn/nganhang.txt', "utf8")
    .split('\n');





c.queue(links)

